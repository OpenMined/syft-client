
#!/bin/bash

# Colors 1234
RED='[0;31m'
GREEN='[0;32m'
YELLOW='[1;33m'
CYAN='[0;36m'
NC='[0m' # No Color

# Clear the screen
clear

# Print header with border
echo -e "${CYAN}==============================${NC}"
echo -e "${GREEN}     🌟 Current Date 🌟     ${NC}"
echo -e "${CYAN}==============================${NC}"

# Animate dots
for i in {1..3}; do
  echo -n "."
  sleep 0.3
done
echo ""

# Print date in yellow
echo -e "${YELLOW}$(date)${NC}"

# Footer
echo -e "${CYAN}==============================${NC}"
